﻿using System.Windows.Controls;

namespace SimpleInventory.Views
{
    /// <summary>
    /// Interaction logic for ManageAppSettings.xaml
    /// </summary>
    public partial class ManageAppSettings : UserControl
    {
        public ManageAppSettings()
        {
            InitializeComponent();
        }
    }
}
